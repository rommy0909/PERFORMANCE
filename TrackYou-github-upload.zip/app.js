const storageKey = 'studentPulseClasses';
const starterClasses = [{ id: 'demo', course: 'BSCS', year: '3rd Year', section: 'A', subjects: ['Data Structures', 'Web Development', 'Database Systems', 'Discrete Mathematics'], students: [{ name: 'Jordan Davis', initials: 'JD', assessments: [] }, { name: 'Maria Santos', initials: 'MS', assessments: [] }, { name: 'Ethan Reyes', initials: 'ER', assessments: [] }] }];
let classes = JSON.parse(localStorage.getItem(storageKey) || 'null') || starterClasses;
let activeClass = classes[0];
let selectedStudent = activeClass.students[0] || null;
let pendingSubjects = [];
let editingClassId = null;
let editingAssessment = null;
let editingStudent = null;

const $ = (selector) => document.querySelector(selector);
const assessmentRows = $('#assessmentRows');
const subjectFilter = $('#subjectFilter');
let periodFilter = $('#periodFilter');
const searchInput = $('#searchInput');
const modalBackdrop = $('#modalBackdrop');
const studentModalBackdrop = $('#studentModalBackdrop');
const classModalBackdrop = $('#classModalBackdrop');
const recommendationsBackdrop = $('#recommendationsBackdrop');
const completionBackdrop = $('#completionBackdrop');
const toast = $('#toast');

function saveClasses() {
  localStorage.setItem(storageKey, JSON.stringify(classes));
  if (window.studentPulseFirebase?.saveStudentPulseClasses) {
    window.studentPulseFirebase.saveStudentPulseClasses(classes).catch(() => showToast('Saved locally. Firebase rules still need setup.'));
  }
}

function syncClassesToFirebase() {
  if (window.studentPulseFirebase?.saveStudentPulseClasses) {
    window.studentPulseFirebase.saveStudentPulseClasses(classes).catch(() => showToast('Saved locally. Firebase rules still need setup.'));
  }
}

async function loadClassesFromFirebase() {
  if (!window.studentPulseFirebase?.loadStudentPulseClasses) return;
  try {
    const remoteClasses = await window.studentPulseFirebase.loadStudentPulseClasses();
    if (!Array.isArray(remoteClasses) || !remoteClasses.length) { syncClassesToFirebase(); return; }
    classes = remoteClasses;
    activeClass = classes[0];
    selectedStudent = activeClass.students[0] || null;
    localStorage.setItem(storageKey, JSON.stringify(classes));
    await window.studentPulseFirebase.saveStudentPulseClasses(classes);
    renderClassOptions();
    $('#activeClassBannerName').textContent = classLabel(activeClass);
    renderSubjects();
    renderStudentSelect();
    renderReports();
  } catch (error) {
    showToast('Using local saved data. Firebase rules still need setup.');
  }
}

window.addEventListener('studentpulse:firebase-ready', loadClassesFromFirebase);
function classLabel(item) { return `${item.course} · ${item.year} · Section ${item.section}`; }
function showToast(message) { toast.textContent = message; toast.classList.add('show'); clearTimeout(window.toastTimer); window.toastTimer = setTimeout(() => toast.classList.remove('show'), 2600); }
function initials(name) { return name.split(/\s+/).map((part) => part[0]).join('').slice(0, 2).toUpperCase(); }
function getStudentInitials(student) {
  const displayText = (student.displayName || student.name || '').trim();
  if (!displayText) return 'NA';
  if (displayText.includes(',')) {
    const [surnamePart, givenPart] = displayText.split(',').map((part) => part.trim());
    if (surnamePart && givenPart) return `${surnamePart.charAt(0)}${givenPart.split(/\s+/)[0].charAt(0)}`.toUpperCase();
  }
  const parts = displayText.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) return `${parts[0].charAt(0)}${parts[parts.length - 1].charAt(0)}`.toUpperCase();
  return displayText.slice(0, 2).toUpperCase();
}
function titleCase(value) { return value.trim().toLowerCase().replace(/\b\w/g, (letter) => letter.toUpperCase()); }
function normalizeSubject(value) { return String(value || '').trim().replace(/\s+/g, ' ').toLowerCase(); }
function getScorePercentage(assessment) {
  const score = Number(assessment?.score);
  const total = Number(assessment?.total);
  if (!Number.isFinite(score) || !Number.isFinite(total) || total <= 0) return 0;
  return Math.max(0, Math.min(100, score / total * 100));
}
function getAssessmentKey(assessment) {
  if (String(assessment?.type || '').trim().toLowerCase() === 'exam') {
    return ['exam', normalizeSubject(assessment?.subject), normalizePeriod(assessment?.period)]
      .map((value) => String(value ?? '').trim().toLowerCase().replace(/\s+/g, ' ')).join('|');
  }
  return [
    assessment?.title,
    normalizeSubject(assessment?.subject),
    assessment?.type,
    normalizePeriod(assessment?.period)
  ].map((value) => String(value ?? '').trim().toLowerCase().replace(/\s+/g, ' ')).join('|');
}
function getUniqueAssessments(assessments) {
  const unique = new Map();
  assessments.forEach((assessment) => {
    const key = getAssessmentKey(assessment);
    if (key !== '|||') unique.set(key, assessment);
  });
  return [...unique.values()];
}
function getMissingAssessments(student, classAssessments) {
  const studentKeys = new Set(student.assessments.map(getAssessmentKey));
  return classAssessments.filter((assessment) => !studentKeys.has(getAssessmentKey(assessment)));
}
function isSameExamPeriod(first, second) {
  return String(first?.type || '').trim().toLowerCase() === 'exam'
    && String(second?.type || '').trim().toLowerCase() === 'exam'
    && normalizeSubject(first?.subject) === normalizeSubject(second?.subject)
    && normalizePeriod(first?.period) === normalizePeriod(second?.period);
}
function formatCourse(value) { return value.trim().split(/\s+/).map((word) => word.length <= 5 ? word.toUpperCase() : `${word[0].toUpperCase()}${word.slice(1).toLowerCase()}`).join(' '); }
function formatStudentName(value) { return value.trim().toLowerCase().split(/\s+/).map((word) => `${word[0].toUpperCase()}${word.slice(1)}`).join(' '); }
function formatSurname(value) { return value.trim().toLowerCase().replace(/\b\w/g, (letter) => letter.toUpperCase()); }
function localDateValue() { const now = new Date(); return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`; }
function localTimeValue() { const now = new Date(); return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`; }
function renderCurrentDate() { const dateLabel = $('#currentDateLabel'); if (dateLabel) dateLabel.textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase(); }
function getStudentAverage(student) {
  if (!student?.assessments?.length) return 0;
  return student.assessments.reduce((sum, item) => sum + getScorePercentage(item), 0) / student.assessments.length;
}
function sortStudentsAlphabetically(students) { return students.slice().sort((a, b) => (a.displayName || a.name || '').localeCompare(b.displayName || b.name || '')); }
function sortStudentsForRoster(students, mode = 'average-desc') {
  const list = students.slice();
  switch (mode) {
    case 'average-asc':
      return list.sort((a, b) => getStudentAverage(a) - getStudentAverage(b));
    case 'name-asc':
      return list.sort((a, b) => (a.displayName || a.name || '').localeCompare(b.displayName || b.name || ''));
    case 'name-desc':
      return list.sort((a, b) => (b.displayName || b.name || '').localeCompare(a.displayName || a.name || ''));
    case 'average-desc':
    default:
      return list.sort((a, b) => getStudentAverage(b) - getStudentAverage(a));
  }
}
function getAssessmentSortValue(assessment) { const dateTime = assessment.dateTime || assessment.date || ''; const time = assessment.time || '00:00'; const candidate = dateTime.includes('T') ? dateTime : `${dateTime}T${time}`; const parsed = new Date(candidate); return Number.isNaN(parsed.getTime()) ? 0 : parsed.getTime(); }
function formatAssessmentTitle(value) { return titleCase(value || ''); }
function getAssessmentDisplayName(item) { const type = titleCase(item.type || 'Assessment'); const title = formatAssessmentTitle(item.title); const period = getPeriodLabel(item.period || 'overall'); return title ? `${type} ${title}` : `${type} · ${period}`; }
const PERIOD_LABELS = { overall: 'Semester', prelim: 'Prelim', midterm: 'Midterm', semifinal: 'Semi Finals', final: 'Finals' };
function normalizePeriod(value) {
  const raw = String(value || '').trim().toLowerCase().replace(/[_\-\s]+/g, '');
  const aliases = {
    overall: 'overall', semester: 'overall', all: 'overall',
    prelim: 'prelim',
    midterm: 'midterm',
    semifinal: 'semifinal', semifinals: 'semifinal', 'semifinals': 'semifinal', 'semifinals': 'semifinal',
    final: 'final', finals: 'final'
  };
  return aliases[raw] || raw || 'overall';
}
function getPeriodLabel(value) { return PERIOD_LABELS[normalizePeriod(value)] || titleCase(String(value || 'Semester')); }
classes = classes.map((item) => ({ ...item, course: formatCourse(item.course), section: item.section.toUpperCase(), subjects: item.subjects.map((subject) => titleCase(subject)), students: item.students.map((student) => { const name = formatStudentName(student.name); const surname = formatSurname(student.surname || ''); const middleName = student.middleName ? formatStudentName(student.middleName) : (student.studentNumber ? formatStudentName(student.studentNumber) : ''); const gender = student.gender || 'Male'; const displayName = student.displayName || (surname ? `${surname}, ${name}` : name); return { ...student, name, surname, middleName, gender, displayName, studentNumber: student.studentNumber || middleName || 'No middle name', initials: student.initials || getStudentInitials({ ...student, displayName, name, surname }), assessments: student.assessments || [] }; }) }));
localStorage.setItem(storageKey, JSON.stringify(classes));

function renderClassOptions() {
  $('#classSelect').innerHTML = classes.map((item) => `<option value="${item.id}">${classLabel(item)}</option>`).join('');
  $('#classSelect').value = activeClass.id;
  $('#reportClassSelect').innerHTML = classes.map((item) => `<option value="${item.id}">${classLabel(item)}</option>`).join('');
  $('#reportClassSelect').value = activeClass.id;
  renderClassCards();
}

function refreshActiveClassViews() {
  if (!activeClass) return;
  $('#activeClassBannerName').textContent = classLabel(activeClass);
  renderClassOptions();
  renderSubjects();
  renderStudentSelect();
  renderReports();
}

function classStudentsWithAverage(item) {
  return item.students.map((student) => {
    const average = student.assessments.length ? student.assessments.reduce((sum, assessment) => sum + (assessment.score / assessment.total * 100), 0) / student.assessments.length : 0;
    return { ...student, average };
  });
}

function renderReports() {
  arrangeClassReportPanels();
  const students = classStudentsWithAverage(activeClass);
  const allAssessments = activeClass.students.flatMap((student) => student.assessments);
  const uniqueAssessments = getUniqueAssessments(allAssessments);
  const classAverage = allAssessments.length ? allAssessments.reduce((sum, item) => sum + (item.score / item.total * 100), 0) / allAssessments.length : 0;
  const completed = uniqueAssessments.length;
  $('#reportClassName').textContent = classLabel(activeClass);
  $('#reportClassMeta').textContent = `${activeClass.subjects.length} subjects · ${activeClass.students.length} students · ${completed} assessments`;
  $('#reportMetrics').innerHTML = `<article class="report-metric"><span>Class average</span><strong>${classAverage.toFixed(1)}%</strong><small>Based on scores</small></article><article class="report-metric"><span>Total students</span><strong>${activeClass.students.length}</strong><small>Enrolled in this class</small></article><article class="report-metric"><span>Assessments</span><strong>${completed}</strong><small>Across all students</small></article><article class="report-metric"><span>Subjects</span><strong>${activeClass.subjects.length}</strong><small>Configured for this class</small></article>`;
  $('#reportSubjects').innerHTML = activeClass.subjects.map((subject) => { const scores = activeClass.students.flatMap((student) => student.assessments.filter((item) => item.subject === subject).map((item) => item.score / item.total * 100)); const average = scores.length ? Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length) : 0; return `<div class="report-subject-row"><div class="report-subject-label"><span>${subject}</span><strong>${average}%</strong></div><div class="report-progress"><span style="width:${average}%"></span></div></div>`; }).join('') || '<p class="muted">No subjects configured.</p>';
  $('#reportCompletion').innerHTML = students.map((student) => { const completedByStudent = getUniqueAssessments(student.assessments).length; const missing = getMissingAssessments(student, uniqueAssessments); const progress = completed ? Math.min(completedByStudent / completed * 100, 100) : 0; const studentKey = student.name.replace(/"/g, '&quot;'); return `<div class="report-completion-row"><div class="report-completion-label"><span>${student.displayName || student.name}</span><strong>${completedByStudent}/${completed}</strong><button class="completion-help-button" type="button" data-completion-student="${studentKey}" aria-label="Show missing assessments" title="Show missing assessments">?</button></div><div class="report-progress"><span style="width:${progress}%"></span></div></div>`; }).join('') || '<p class="muted">No students added.</p>';
  const completionSubtitle = document.querySelector('.report-completion-panel .muted');
  if (completionSubtitle) completionSubtitle.textContent = 'Student assessment progress';
  $('#reportRanking').innerHTML = students.sort((a, b) => b.average - a.average).slice(0, 3).map((student, index) => `<div class="report-rank-card"><span class="rank-number">${index + 1}</span><span class="avatar card-avatar">${student.initials}</span><span class="report-rank-copy"><strong>${student.displayName || student.name}</strong><small>${student.assessments.length} assessments</small></span><strong class="report-rank-score">${student.average.toFixed(1)}%</strong></div>`).join('') || '<p class="muted">No students added.</p>';
  renderClassReportAnalytics();
}

function arrangeClassReportPanels() {
  const analytics = document.querySelector('.report-analytics');
  const reportGrid = document.querySelector('.reports-view .report-grid');
  const completion = document.querySelector('.report-completion-panel');
  if (!analytics || !reportGrid || !completion || completion.parentElement === analytics) return;
  analytics.appendChild(completion);
  reportGrid.remove();
}

function renderClassReportAnalytics() {
  const reportPeriodSelect = $('#reportSubjectPeriod');
  if (reportPeriodSelect && !reportPeriodSelect.value) reportPeriodSelect.value = 'overall';
  if (reportPeriodSelect) {
    const labels = { overall: 'Semester', prelim: 'Prelim', midterm: 'Midterm', semifinal: 'Semi Finals', final: 'Finals' };
    [...reportPeriodSelect.options].forEach((option) => { if (labels[option.value]) option.textContent = labels[option.value]; });
  }
  const trendPeriodSelect = $('#reportTrendPeriod');
  if (trendPeriodSelect && !trendPeriodSelect.value) trendPeriodSelect.value = 'overall';
  if (trendPeriodSelect) {
    const labels = { overall: 'Semester', prelim: 'Prelim', midterm: 'Midterm', semifinal: 'Semi Finals', final: 'Finals' };
    [...trendPeriodSelect.options].forEach((option) => { if (labels[option.value]) option.textContent = labels[option.value]; });
  }
  const trendPeriod = normalizePeriod(trendPeriodSelect?.value || 'overall');
  const subjectPeriod = normalizePeriod(reportPeriodSelect?.value || 'overall');
  const allAssessments = activeClass.students.flatMap((student) => student.assessments).filter((item) => {
    if (trendPeriod === 'overall') return true;
    return normalizePeriod(item.period) === trendPeriod;
  }).sort((a, b) => getAssessmentSortValue(a) - getAssessmentSortValue(b));
  const trendRange = $('#reportTrendRange')?.value || 'overall';
  const trendData = getTrendAssessments(allAssessments, trendRange);
  const trendLabel = $('#reportTrendLabel');
  if (trendLabel) trendLabel.textContent = `Whole class score over time · ${getPeriodLabel(trendPeriod)}`;
  drawTrendCanvas('#reportTrendChart', '#reportChartEmpty', trendData);
  const subjectLabel = $('#reportSubjectLabel');
  if (subjectLabel) subjectLabel.textContent = `Whole class average by subject · ${getPeriodLabel(subjectPeriod)}`;
  const subjectAssessments = activeClass.students.flatMap((student) => student.assessments).filter((item) => {
    if (subjectPeriod === 'overall') return true;
    return normalizePeriod(item.period) === subjectPeriod;
  });
  $('#reportSubjects').innerHTML = activeClass.subjects.map((subject) => {
    const normalizedSubject = normalizeSubject(subject);
    const scores = subjectAssessments.filter((item) => normalizeSubject(item.subject) === normalizedSubject).map(getScorePercentage);
    const average = scores.length ? Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length) : 0;
    return `<div class="report-subject-row"><div class="report-subject-label"><span>${subject}</span><strong>${average}%</strong></div><div class="report-progress"><span style="width:${average}%"></span></div></div>`;
  }).join('') || '<p class="muted">No subjects configured.</p>';
}

function drawTrendCanvas(canvasSelector, emptySelector, assessments) {
  const canvas = $(canvasSelector);
  const empty = $(emptySelector);
  if (!canvas) return;
  if (empty) empty.hidden = assessments.length > 0;
  const context = canvas.getContext('2d');
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth || 600;
  const height = canvas.clientHeight || 220;
  canvas.width = width * ratio;
  canvas.height = height * ratio;
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  context.clearRect(0, 0, width, height);
  if (!assessments.length) return;
  const padding = { top: 18, right: 18, bottom: 30, left: 38 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  const x = (index) => padding.left + (assessments.length === 1 ? chartWidth / 2 : index / (assessments.length - 1) * chartWidth);
  const y = (score) => padding.top + (100 - score) / 100 * chartHeight;
  context.font = '10px DM Sans';
  context.strokeStyle = '#27303b';
  context.fillStyle = '#8994a3';
  [0, 25, 50, 75, 100].forEach((value) => { const lineY = y(value); context.beginPath(); context.moveTo(padding.left, lineY); context.lineTo(width - padding.right, lineY); context.stroke(); context.fillText(`${value}%`, 4, lineY + 3); });
  drawSmoothTrend(context, assessments, x, y, height - padding.bottom);
  assessments.forEach((item, index) => { context.fillStyle = '#5ee6dc'; context.beginPath(); context.arc(x(index), y(item.score), 4, 0, Math.PI * 2); context.fill(); context.fillStyle = '#8994a3'; context.fillText(item.label.slice(0, 16), Math.max(padding.left, x(index) - 24), height - 9); });
}

function renderClassCards() {
  $('#classCards').innerHTML = classes.map((item) => `<article class="class-card"><div class="class-card-header"><div><h3>${item.course}</h3><span class="class-card-meta">${item.year} · Section ${item.section}</span></div><span class="class-badge">${item.students.length} ${item.students.length === 1 ? 'student' : 'students'}</span></div><div class="class-card-subjects">${item.subjects.map((subject) => `<span>${subject}</span>`).join('')}</div><div class="class-card-footer"><span>${item.subjects.length} ${item.subjects.length === 1 ? 'subject' : 'subjects'} configured</span><div class="class-card-actions"><button data-action="edit" data-id="${item.id}">Edit</button><button class="delete-class" data-action="delete" data-id="${item.id}">Delete</button></div></div></article>`).join('');
}

function renderSubjects() {
  const subjectOptions = activeClass.subjects.map((subject) => `<option value="${subject}">${subject}</option>`).join('');
  $('#assessmentSubject').innerHTML = subjectOptions || '<option value="">Create a class subject first</option>';
  subjectFilter.innerHTML = '<option value="all">All subjects</option>' + subjectOptions;
  configureAssessmentPeriodFilter();
}

function configureAssessmentPeriodFilter() {
  if (periodFilter || !subjectFilter?.parentElement) return;
  const select = document.createElement('select');
  select.id = 'periodFilter';
  select.innerHTML = '<option value="all">All periods</option><option value="prelim">Prelim</option><option value="midterm">Midterm</option><option value="semifinal">Semi Finals</option><option value="final">Finals</option>';
  subjectFilter.parentElement.insertBefore(select, subjectFilter.nextSibling);
  periodFilter = select;
  select.addEventListener('change', filterAssessments);
}

function renderAssessmentStudentSelect(student = selectedStudent) {
  const studentSelect = $('#assessmentStudent');
  if (!studentSelect) return;
  studentSelect.innerHTML = sortStudentsAlphabetically(activeClass.students).map((item) => `<option value="${item.name}">${item.displayName || item.name}</option>`).join('');
  if (student && activeClass.students.some((item) => item.name === student.name)) studentSelect.value = student.name;
  studentSelect.disabled = Boolean(editingAssessment);
}

function renderStudentSelect() {
  $('#studentStrip').hidden = activeClass.students.length === 0;
  $('#classEmptyPanel').hidden = activeClass.students.length > 0;
  $('#rosterPanel').hidden = activeClass.students.length === 0;
  $('#activeClassBannerMeta').textContent = `${activeClass.subjects.length} subjects · ${activeClass.students.length} students tracked`;
  $('#studentClassContext').textContent = `Adding to ${classLabel(activeClass)}`;
  $('#studentSelect').innerHTML = sortStudentsAlphabetically(activeClass.students).map((student) => `<option value="${student.name}">${student.displayName || student.name}</option>`).join('');
  if (selectedStudent && activeClass.students.some((student) => student.name === selectedStudent.name)) $('#studentSelect').value = selectedStudent.name;
  else selectedStudent = activeClass.students[0] || null;
  renderSelectedStudent();
  renderTopStudents();
  renderStudentCards();
  renderSubjectPerformance();
}

function renderSubjectPerformance() {
  const subjectColors = ['blue', 'violet', 'orange-dot', 'pink'];
  configureSubjectPeriod();
  const subjectPeriodSelect = $('#subjectPeriod');
  const selectedPeriod = normalizePeriod(subjectPeriodSelect?.value || 'overall');
  if (subjectPeriodSelect && !subjectPeriodSelect.value) subjectPeriodSelect.value = 'overall';
  const studentAssessments = selectedStudent ? selectedStudent.assessments.filter((item) => selectedPeriod === 'overall' || normalizePeriod(item.period) === selectedPeriod) : [];
  const subjectLabel = $('#subjectPerformanceLabel');
  if (subjectLabel) subjectLabel.textContent = selectedStudent ? `${selectedStudent.displayName || selectedStudent.name}'s average by subject · ${selectedPeriod === 'overall' ? 'Semester' : getPeriodLabel(selectedPeriod)}` : 'Select a student to view subject performance';
  const rows = activeClass.subjects.map((subject, index) => {
    const normalizedSubject = normalizeSubject(subject);
    const results = studentAssessments.filter((item) => normalizeSubject(item.subject) === normalizedSubject).map(getScorePercentage);
    const average = results.length ? Math.round(results.reduce((sum, score) => sum + score, 0) / results.length) : 0;
    const color = subjectColors[index % subjectColors.length];
    const classSubjectAssessments = getUniqueAssessments(activeClass.students.flatMap((student) => student.assessments).filter((item) => normalizeSubject(item.subject) === normalizedSubject && (selectedPeriod === 'overall' || normalizePeriod(item.period) === selectedPeriod)));
    const missing = selectedStudent ? getMissingAssessments(selectedStudent, classSubjectAssessments) : [];
    const recordedText = results.length ? `${results.length} assessment${results.length === 1 ? '' : 's'} recorded` : 'No assessment recorded yet';
    const missingText = missing.length ? ` <button class="subject-missing-button" type="button" data-missing-subject="${encodeURIComponent(subject)}" aria-label="Show missing assessments" title="Show missing assessments">?</button><strong class="subject-missing-count">${missing.length}</strong>` : '';
    return `<div class="subject-row"><div class="subject-title"><span class="subject-dot ${color}"></span><span>${subject}</span><strong>${average}%</strong></div><div class="bar-track"><span class="bar ${color}-bar" style="width:${average}%"></span></div><small class="subject-trend ${missing.length || average < 75 ? 'negative' : 'positive'}">${recordedText}${missingText}</small></div>`;
  }).join('');
  $('#subjectPerformanceList').innerHTML = rows || '<p class="muted">No subjects configured for this class.</p>';
  renderRecommendations();
}

function configureSubjectPeriod() {
  const heading = document.querySelector('.subject-panel .panel-heading');
  if (!heading || $('#subjectPeriod')) return;
  const select = document.createElement('select');
  select.id = 'subjectPeriod';
  select.hidden = true;
  select.value = 'overall';
  select.innerHTML = '<option value="overall">Semester</option><option value="prelim">Prelim</option><option value="midterm">Midterm</option><option value="semifinal">Semi Finals</option><option value="final">Finals</option>';
  heading.insertBefore(select, heading.querySelector('.more-button'));
  const menu = document.createElement('div');
  menu.id = 'subjectPeriodMenu';
  menu.className = 'subject-period-menu';
  menu.innerHTML = [...select.options].map((option) => `<button type="button" data-period="${option.value}">${option.textContent}</button>`).join('');
  heading.appendChild(menu);
  heading.querySelector('.more-button')?.addEventListener('click', () => menu.classList.toggle('open'));
  menu.addEventListener('click', (event) => {
    const button = event.target.closest('[data-period]');
    if (!button) return;
    const nextPeriod = button.dataset.period;
    select.value = nextPeriod;
    menu.classList.remove('open');
    select.dispatchEvent(new Event('change', { bubbles: true }));
  });
  select.addEventListener('change', () => {
    renderSubjectPerformance();
  });
}

function configureAnalyticsPeriod() {
  const trendSelect = $('#rangeSelect');
  const periodSelect = $('#analyticsPeriod') || (() => {
    const select = document.createElement('select');
    select.id = 'analyticsPeriod';
    select.innerHTML = '<option value="overall">Semester</option><option value="prelim">Prelim</option><option value="midterm">Midterm</option><option value="semifinal">Semi Finals</option><option value="final">Finals</option>';
    trendSelect?.parentElement.appendChild(select);
    return select;
  })();
  if (trendSelect && !trendSelect.dataset.configured) {
    trendSelect.innerHTML = '<option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option><option value="overall">Overall</option>';
    trendSelect.value = 'overall';
    trendSelect.dataset.configured = 'true';
    trendSelect.addEventListener('change', renderTrendChart);
  }
  if (periodSelect && !periodSelect.dataset.configured) {
    periodSelect.innerHTML = '<option value="overall">Semester</option><option value="prelim">Prelim</option><option value="midterm">Midterm</option><option value="semifinal">Semi Finals</option><option value="final">Finals</option>';
    periodSelect.value = 'overall';
    periodSelect.dataset.configured = 'true';
    periodSelect.addEventListener('change', () => { renderTrendChart(); renderSubjectPerformance(); renderAssessmentRows(); });
  }
}

function renderRecommendations() {
  const selectedPeriod = normalizePeriod($('#analyticsPeriod')?.value || 'overall');
  const scoredSubjects = activeClass.subjects.map((subject) => {
    const normalizedSubject = normalizeSubject(subject);
    const scores = selectedStudent ? selectedStudent.assessments.filter((item) => normalizeSubject(item.subject) === normalizedSubject && (selectedPeriod === 'overall' || normalizePeriod(item.period) === selectedPeriod)).map((item) => item.score / item.total * 100) : [];
    return { subject, average: scores.length ? scores.reduce((sum, score) => sum + score, 0) / scores.length : null };
  });
  const needsAttention = scoredSubjects.filter((item) => item.average !== null && item.average < 75);
  $('#attentionCount').innerHTML = `${needsAttention.length}<span class="streak-label"> ${needsAttention.length === 1 ? 'subject' : 'subjects'}</span>`;
  $('#attentionSubjects').textContent = needsAttention.length ? needsAttention.map((item) => item.subject).join(' and ') : 'No subjects need attention';
  $('#recommendationsStudent').textContent = selectedStudent ? `For ${selectedStudent.displayName || selectedStudent.name}` : 'Select a student first';
  $('#recommendationList').innerHTML = needsAttention.length ? needsAttention.map((item) => `<div class="recommendation-item"><span class="recommendation-icon">!</span><div><strong>Review ${item.subject}</strong><p>Current average is ${Math.round(item.average)}%. Add a practice assessment or review the latest feedback.</p></div></div>`).join('') : `<div class="recommendation-item"><span class="recommendation-icon good">✓</span><div><strong>${selectedStudent ? 'No urgent recommendations' : 'Select a student first'}</strong><p>${selectedStudent ? 'Keep recording assessments to keep this progress current.' : 'Choose a student to see subject-specific recommendations.'}</p></div></div>`;
}

function renderStudentCards() {
  const sortMode = $('#rosterSort')?.value || 'average-desc';
  $('#studentCards').innerHTML = sortStudentsForRoster(activeClass.students, sortMode).map((student) => {
    const average = student.assessments.length ? Math.round(getStudentAverage(student)) : 0;
    const selected = selectedStudent && selectedStudent.name === student.name ? ' selected-card' : '';
    const middleNameText = student.middleName ? student.middleName : 'No middle name';
    const genderText = student.gender || 'Male';
    return `<button class="student-card${selected}" data-student="${student.name}"><span class="avatar card-avatar">${student.initials}</span><span class="student-card-copy"><strong>${student.displayName}</strong><small>${middleNameText} · ${genderText} · ${student.assessments.length} assessment${student.assessments.length === 1 ? '' : 's'}</small></span><strong class="card-average">${average}%</strong><span class="top-arrow">→</span></button>`;
  }).join('');
}

function renderTopStudents() {
  const filterSelect = $('#topStudentsType');
  if (filterSelect) {
    const currentValue = filterSelect.value || 'all';
    filterSelect.innerHTML = '<option value="all">All subjects</option>' + activeClass.subjects.map((subject) => `<option value="${subject}">${subject}</option>`).join('');
    if (activeClass.subjects.some((subject) => subject === currentValue) || currentValue === 'all') filterSelect.value = currentValue;
    else filterSelect.value = 'all';
    filterSelect.onchange = () => renderTopStudents();
  }

  const selectedSubject = filterSelect?.value || 'all';
  const ranked = activeClass.students.map((student) => {
    const relevantAssessments = selectedSubject === 'all'
      ? student.assessments
      : student.assessments.filter((item) => item.subject === selectedSubject);
    const average = relevantAssessments.length ? relevantAssessments.reduce((sum, item) => sum + (item.score / item.total * 100), 0) / relevantAssessments.length : 0;
    return { ...student, average, assessmentCount: relevantAssessments.length };
  }).sort((a, b) => b.average - a.average).slice(0, 3);

  document.querySelectorAll('.top-student').forEach((card, index) => {
    const student = ranked[index];
    if (!student) { card.hidden = true; return; }
    card.hidden = false;
    const initialsValue = getStudentInitials(student);
    const studentKey = student.displayName || student.name;
    card.dataset.student = studentKey;
    card.setAttribute('data-student', studentKey);
    card.querySelector('.top-avatar').textContent = initialsValue;
    card.querySelector('.top-student-copy strong').textContent = studentKey;
    card.querySelector('.top-student-copy small').textContent = `${student.assessmentCount} ${selectedSubject === 'all' ? 'assessments completed' : `${selectedSubject} assessments`}`;
    card.querySelector('.top-score').textContent = `${student.average.toFixed(1)}%`;
    card.onclick = () => {
      const selectedName = card.dataset.student || card.getAttribute('data-student');
      if (!selectedName) return;
      const matchedStudent = activeClass.students.find((entry) => {
        const display = entry.displayName || entry.name;
        return entry.name === selectedName || display === selectedName || `${entry.surname || display.split(',')[0]}, ${entry.name}` === selectedName;
      });
      if (!matchedStudent) return;
      selectedStudent = matchedStudent;
      renderStudentSelect();
      renderSelectedStudent();
      renderSubjectPerformance();
      showToast(`${selectedStudent.name}'s profile loaded.`);
    };
  });

  const basisLabel = selectedSubject === 'all' ? 'all subjects' : selectedSubject;
  $('#topStudentsClassLabel').textContent = `${classLabel(activeClass)} · Based on ${basisLabel}`;
}

function renderSelectedStudent() {
  if (!selectedStudent) return;
  $('#studentSelect').value = selectedStudent.name;
  $('.avatar-large').textContent = selectedStudent.initials;
  $('.student-name').innerHTML = `${selectedStudent.name} <span class="verified">✓</span>`;
  $('#selectedStudentMeta').textContent = classLabel(activeClass);
  const average = selectedStudent.assessments.length ? Math.round(selectedStudent.assessments.reduce((sum, item) => sum + (item.score / item.total * 100), 0) / selectedStudent.assessments.length) : 0;
  $('.kpi-value').innerHTML = `${average}<span class="unit">%</span>`;
  $('.progress-line span').style.width = `${average}%`;
  document.querySelectorAll('.kpi-value')[1].innerHTML = `${selectedStudent.assessments.length}`;
  const assessmentFootnote = document.querySelector('.kpi-card:nth-child(2) .footnote');
  if (assessmentFootnote) assessmentFootnote.textContent = 'Based on recorded assessments';
  renderAssessmentRows();
  renderTrendChart();
}

function getTrendBucket(dateValue, range) {
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) return 'Unknown';
  if (range === 'daily') return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  if (range === 'monthly') return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  if (range === 'weekly') {
    const start = new Date(date);
    start.setDate(date.getDate() - date.getDay());
    return `Week of ${start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;
  }
  return 'Overall';
}

function getTrendAssessments(assessments, range) {
  if (range === 'overall') {
    return assessments.map((item, index) => ({ label: item.dateLabel || `Assessment ${index + 1}`, score: item.total ? item.score / item.total * 100 : 0 }));
  }
  const groups = new Map();
  assessments.forEach((item) => {
    const label = getTrendBucket(item.dateTime || `${item.date}T${item.time || '00:00'}`, range);
    const group = groups.get(label) || { label, scores: [] };
    group.scores.push(item.total ? item.score / item.total * 100 : 0);
    groups.set(label, group);
  });
  return [...groups.values()].map((group) => ({ label: group.label, score: group.scores.reduce((sum, score) => sum + score, 0) / group.scores.length }));
}

function drawSmoothTrend(context, assessments, x, y, bottom) {
  if (!assessments.length) return;
  context.beginPath();
  context.lineJoin = 'round';
  context.lineCap = 'round';

  if (assessments.length === 1) {
    const firstX = x(0);
    const firstY = y(assessments[0].score);
    context.moveTo(firstX, bottom);
    context.lineTo(firstX, firstY);
  } else {
    context.moveTo(x(0), y(assessments[0].score));
    for (let index = 1; index < assessments.length; index += 1) {
      const previousX = x(index - 1);
      const currentX = x(index);
      const previousY = y(assessments[index - 1].score);
      const currentY = y(assessments[index].score);
      const midpointX = (previousX + currentX) / 2;
      const midpointY = (previousY + currentY) / 2;
      context.quadraticCurveTo(previousX, previousY, midpointX, midpointY);
      context.lineTo(currentX, currentY);
    }
  }

  context.strokeStyle = '#5ee6dc';
  context.lineWidth = 2.5;
  context.shadowColor = 'rgba(94,230,220,0.35)';
  context.shadowBlur = 10;
  context.stroke();
  context.shadowColor = 'transparent';
  context.shadowBlur = 0;

  if (assessments.length > 1) {
    const lastX = x(assessments.length - 1);
    const firstX = x(0);
    context.lineTo(lastX, bottom);
    context.lineTo(firstX, bottom);
    context.closePath();
    context.fillStyle = 'rgba(94,230,220,.12)';
    context.fill();
  }
}

function configureTrendRange() {
  const rangeSelect = $('#rangeSelect');
  if (!rangeSelect || rangeSelect.dataset.configured) return;
  rangeSelect.innerHTML = '<option value="daily">Daily</option><option value="weekly">Weekly</option><option value="monthly">Monthly</option><option value="overall" selected>Overall</option>';
  rangeSelect.dataset.configured = 'true';
  rangeSelect.addEventListener('change', renderTrendChart);
}

function renderTrendChart() {
  const canvas = $('#trendChart');
  const empty = $('#chartEmpty');
  const trendLabel = $('#trendLabel');
  if (!canvas) return;
  configureAnalyticsPeriod();
  const range = $('#rangeSelect')?.value || 'overall';
  const selectedPeriod = normalizePeriod($('#analyticsPeriod')?.value || 'overall');
  const rawAssessments = selectedStudent ? selectedStudent.assessments.filter((item) => selectedPeriod === 'overall' || normalizePeriod(item.period) === selectedPeriod).slice().sort((a, b) => getAssessmentSortValue(a) - getAssessmentSortValue(b)) : [];
  const assessments = getTrendAssessments(rawAssessments, range);
  if (trendLabel) trendLabel.textContent = selectedStudent ? `${selectedStudent.displayName || selectedStudent.name}'s score over time · ${getPeriodLabel(selectedPeriod)}` : 'Select a student to view performance';
  if (empty) empty.hidden = assessments.length > 0;
  const context = canvas.getContext('2d');
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth || 600;
  const height = canvas.clientHeight || 220;
  canvas.width = width * ratio;
  canvas.height = height * ratio;
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  context.clearRect(0, 0, width, height);
  if (!assessments.length) return;
  const padding = { top: 18, right: 18, bottom: 30, left: 38 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  const x = (index) => padding.left + (assessments.length === 1 ? chartWidth / 2 : index / (assessments.length - 1) * chartWidth);
  const y = (score) => padding.top + (100 - score) / 100 * chartHeight;
  context.font = '10px DM Sans';
  context.strokeStyle = '#27303b';
  context.fillStyle = '#8994a3';
  context.lineWidth = 1;
  [0, 25, 50, 75, 100].forEach((value) => { const lineY = y(value); context.beginPath(); context.moveTo(padding.left, lineY); context.lineTo(width - padding.right, lineY); context.stroke(); context.fillText(`${value}%`, 4, lineY + 3); });
  drawSmoothTrend(context, assessments, x, y, height - padding.bottom);
  assessments.forEach((assessment, index) => { const score = assessment.score; context.fillStyle = '#5ee6dc'; context.beginPath(); context.arc(x(index), y(score), 4, 0, Math.PI * 2); context.fill(); context.fillStyle = '#8994a3'; context.fillText(assessment.label.slice(0, 16), Math.max(padding.left, x(index) - 24), height - 9); });
}

function renderAssessmentRows() {
  const rows = selectedStudent ? selectedStudent.assessments.map((item, assessmentIndex) => ({ ...item, student: selectedStudent.name, assessmentIndex })) : [];
  const assessmentStudentLabel = $('#assessmentStudentLabel');
  if (assessmentStudentLabel) assessmentStudentLabel.textContent = selectedStudent ? `Latest scores for ${selectedStudent.displayName || selectedStudent.name}` : 'Select a student to view assessments';
  configureAssessmentPeriodFilter();
  assessmentRows.innerHTML = rows.length ? rows.sort((a, b) => getAssessmentSortValue(b) - getAssessmentSortValue(a)).map((item) => `<tr data-subject="${item.subject}" data-period="${(item.period || 'unassigned').toLowerCase()}" data-student="${item.student}" data-assessment-index="${item.assessmentIndex}"><td><div class="assessment-name"><span class="type-icon blue-bg">${(item.type || 'A')[0]}</span><div><strong>${getAssessmentDisplayName(item)}</strong><small>${item.student} · ${item.type || 'Assessment'} · ${item.period || 'Unassigned'}${item.reference ? ` · ${item.reference}` : ''}</small></div></div></td><td>${item.subject}</td><td>${item.dateLabel || 'No date'}</td><td><strong>${item.score} / ${item.total}</strong><small class="${item.score / item.total >= .85 ? 'score-good' : item.score / item.total >= .75 ? 'score-warn' : 'score-low'}">${Math.round(item.score / item.total * 100)}%</small></td><td><span class="status completed">Completed</span></td><td><button class="edit-assessment" data-student="${item.student}" data-assessment-index="${item.assessmentIndex}">Edit</button></td></tr>`).join('') : '<tr><td colspan="6" class="table-empty">No assessments recorded for this class yet.</td></tr>';
  filterAssessments();
}

function filterAssessments() {
  const subject = subjectFilter.value.toLowerCase();
  const query = searchInput.value.toLowerCase();
  const period = periodFilter?.value.toLowerCase() || 'all';
  const dataRows = [...assessmentRows.querySelectorAll('tr[data-subject]')];
  dataRows.forEach((row) => { row.hidden = !(row.textContent.toLowerCase().includes(query) && (subject === 'all' || row.dataset.subject.toLowerCase() === subject) && (period === 'all' || row.dataset.period.toLowerCase() === period)); });
  const emptyRow = assessmentRows.querySelector('.period-empty');
  if (emptyRow) emptyRow.remove();
  if (!dataRows.some((row) => !row.hidden)) assessmentRows.insertAdjacentHTML('beforeend', '<tr class="period-empty"><td colspan="6" class="table-empty">No assessments found for the selected filters.</td></tr>');
}

function syncAssessmentTitleRequirement() { const type = $('#assessmentType'); const title = $('#assessmentTitle'); if (!type || !title) return; const isExam = type.value.toLowerCase() === 'exam'; title.required = !isExam; title.placeholder = isExam ? 'Optional for exams' : 'e.g. Quiz 1 or Capstone Project'; }
function validateAssessmentScore() { const score = $('#assessmentScore'); const total = $('#assessmentTotal'); const warning = $('#scoreWarning'); if (!score || !total || !warning) return true; const invalid = score.value !== '' && total.value !== '' && Number(score.value) > Number(total.value); warning.hidden = !invalid; score.setCustomValidity(invalid ? 'Score cannot be greater than Out of.' : ''); return !invalid; }
function openAssessmentModal() { editingAssessment = null; renderSubjects(); $('#assessmentModalTitle').textContent = 'Add assessment'; $('#saveAssessmentButton').textContent = 'Save assessment'; $('#deleteAssessmentButton').hidden = true; $('#assessmentForm').reset(); renderAssessmentStudentSelect(); $('#assessmentForm').elements.date.value = localDateValue(); $('#assessmentForm').elements.time.value = localTimeValue(); syncAssessmentTitleRequirement(); modalBackdrop.hidden = false; }
function openEditAssessment(studentName, assessmentIndex) { const student = activeClass.students.find((item) => item.name === studentName); const assessment = student?.assessments[assessmentIndex]; if (!assessment) return; editingAssessment = { student, assessment }; renderSubjects(); renderAssessmentStudentSelect(student); $('#assessmentModalTitle').textContent = 'Edit assessment'; $('#saveAssessmentButton').textContent = 'Save changes'; $('#deleteAssessmentButton').hidden = false; $('#assessmentForm').elements.title.value = assessment.title || ''; $('#assessmentForm').elements.subject.value = assessment.subject || activeClass.subjects[0]; $('#assessmentForm').elements.type.value = assessment.type || 'Quiz'; $('#assessmentForm').elements.period.value = assessment.period || 'Prelim'; $('#assessmentForm').elements.score.value = assessment.score; $('#assessmentForm').elements.total.value = assessment.total; $('#assessmentForm').elements.date.value = assessment.date || localDateValue(); $('#assessmentForm').elements.time.value = assessment.time || localTimeValue(); syncAssessmentTitleRequirement(); validateAssessmentScore(); modalBackdrop.hidden = false; }
function closeAllModals() { modalBackdrop.hidden = true; studentModalBackdrop.hidden = true; classModalBackdrop.hidden = true; }

function arrangeOverviewSections() {
  const mainContent = $('.main-content');
  const topStudents = $('.top-students-panel');
  const studentStrip = $('#studentStrip');
  const roster = $('#rosterPanel');
  const overview = $('#overviewView');
  if (topStudents && overview) overview.insertBefore(topStudents, overview.firstElementChild);
  if (studentStrip && overview && topStudents) overview.insertBefore(studentStrip, topStudents.nextElementSibling);
  if (roster && overview) overview.appendChild(roster);
}

function setMobileMenu(open) {
  document.body.classList.toggle('mobile-menu-open', open);
  const toggle = $('#mobileMenuToggle');
  if (toggle) {
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  }
}

$('#mobileMenuToggle').addEventListener('click', () => setMobileMenu(!document.body.classList.contains('mobile-menu-open')));
$('#mobileMenuOverlay').addEventListener('click', () => setMobileMenu(false));

document.querySelectorAll('.nav-item[data-view]').forEach((item) => item.addEventListener('click', () => {
  document.querySelectorAll('.nav-item[data-view]').forEach((nav) => nav.classList.remove('active'));
  item.classList.add('active');
  const isOverview = item.dataset.view === 'overview';
  $('#overviewView').hidden = !isOverview;
  $('#pageHeading').hidden = !isOverview;
  $('#classManagerView').hidden = item.dataset.view !== 'class-maker';
  $('#reportsView').hidden = item.dataset.view !== 'reports';
  $('.active-class-banner').hidden = !isOverview;
  $('.class-picker-strip').hidden = !isOverview;
  $('#studentStrip').hidden = !isOverview || !activeClass.students.length;
  $('#emptyView').hidden = isOverview || item.dataset.view === 'reports';
  if (item.dataset.view === 'reports') renderReports();
  $('.breadcrumbs strong').textContent = item.dataset.label;
  setMobileMenu(false);
}));

$('#classSelect').addEventListener('change', (event) => { activeClass = classes.find((item) => item.id === event.target.value); selectedStudent = activeClass.students[0] || null; $('#activeClassBannerName').textContent = classLabel(activeClass); renderSubjects(); renderStudentSelect(); renderReports(); showToast(`${classLabel(activeClass)} selected.`); });
$('#reportClassSelect').addEventListener('change', (event) => { activeClass = classes.find((item) => item.id === event.target.value); selectedStudent = activeClass.students[0] || null; $('#classSelect').value = activeClass.id; $('#activeClassBannerName').textContent = classLabel(activeClass); renderSubjects(); renderStudentSelect(); renderReports(); showToast(`${classLabel(activeClass)} report loaded.`); });
$('#reportTrendRange').addEventListener('change', renderClassReportAnalytics);
$('#reportTrendPeriod').addEventListener('change', renderClassReportAnalytics);
$('#reportSubjectPeriod').addEventListener('change', renderClassReportAnalytics);
$('#reportSubjectMenu').addEventListener('click', () => {
  const select = $('#reportSubjectPeriod');
  let menu = $('#reportSubjectPeriodMenu');
  if (!menu) {
    menu = document.createElement('div');
    menu.id = 'reportSubjectPeriodMenu';
    menu.className = 'report-period-menu';
    menu.innerHTML = [...select.options].map((option) => `<button type="button" data-period="${option.value}">${option.textContent}</button>`).join('');
    select.parentElement.appendChild(menu);
    menu.addEventListener('click', (event) => {
      const button = event.target.closest('[data-period]');
      if (!button) return;
      select.value = button.dataset.period;
      menu.classList.remove('open');
      renderClassReportAnalytics();
    });
  }
  menu.classList.toggle('open');
});
$('#reportCompletion').addEventListener('click', (event) => {
  const button = event.target.closest('[data-completion-student]');
  if (!button || !completionBackdrop) return;
  const student = activeClass.students.find((item) => item.name === button.dataset.completionStudent);
  if (!student) return;
  const allAssessments = getUniqueAssessments(activeClass.students.flatMap((item) => item.assessments));
  const missing = getMissingAssessments(student, allAssessments);
  $('#completionModalTitle').textContent = `${student.displayName || student.name}'s missing assessments`;
  $('#missingAssessmentList').innerHTML = missing.length ? missing.map((assessment) => { const type = titleCase(assessment.type || 'Assessment'); const title = assessment.title ? formatAssessmentTitle(assessment.title) : `${getPeriodLabel(assessment.period)} Exam`; return `<div class="missing-assessment-item"><div><div class="missing-assessment-heading"><span class="missing-assessment-type">${type}</span><strong>${title}</strong></div><small>${assessment.subject} · ${getPeriodLabel(assessment.period)}</small></div></div>`; }).join('') : '<p class="missing-assessment-empty">Complete. This student has all recorded assessments.</p>';
  completionBackdrop.hidden = false;
});
$('#closeCompletion').addEventListener('click', () => { completionBackdrop.hidden = true; });
$('#subjectPerformanceList').addEventListener('click', (event) => {
  const button = event.target.closest('.subject-missing-button');
  if (!button || !selectedStudent || !completionBackdrop) return;
  const subject = decodeURIComponent(button.dataset.missingSubject);
  const selectedPeriod = normalizePeriod($('#subjectPeriod')?.value || $('#analyticsPeriod')?.value || 'overall');
  const classAssessments = getUniqueAssessments(activeClass.students.flatMap((student) => student.assessments).filter((item) => normalizeSubject(item.subject) === normalizeSubject(subject) && (selectedPeriod === 'overall' || normalizePeriod(item.period) === selectedPeriod)));
  const missing = getMissingAssessments(selectedStudent, classAssessments);
  $('#completionModalTitle').textContent = `${selectedStudent.displayName || selectedStudent.name} · ${subject}`;
  $('#missingAssessmentList').innerHTML = missing.map((assessment) => { const type = titleCase(assessment.type || 'Assessment'); const title = assessment.title ? formatAssessmentTitle(assessment.title) : `${getPeriodLabel(assessment.period)} Exam`; return `<div class="missing-assessment-item"><div><div class="missing-assessment-heading"><span class="missing-assessment-type">${type}</span><strong>${title}</strong></div><small>${assessment.subject} · ${getPeriodLabel(assessment.period)}</small></div></div>`; }).join('');
  completionBackdrop.hidden = false;
});
$('#studentSelect').addEventListener('change', (event) => { selectedStudent = activeClass.students.find((student) => student.name === event.target.value); renderSelectedStudent(); renderSubjectPerformance(); showToast(`${selectedStudent.name}'s profile loaded.`); });
$('#assessmentStudent').addEventListener('change', (event) => { const student = activeClass.students.find((item) => item.name === event.target.value); if (!student || editingAssessment) return; selectedStudent = student; renderSelectedStudent(); renderSubjectPerformance(); });
$('#assessmentType').addEventListener('change', syncAssessmentTitleRequirement);
$('#assessmentScore').addEventListener('input', validateAssessmentScore);
$('#assessmentTotal').addEventListener('input', validateAssessmentScore);
$('#openRecommendations').addEventListener('click', () => { renderRecommendations(); recommendationsBackdrop.hidden = false; });
$('#closeRecommendations').addEventListener('click', () => { recommendationsBackdrop.hidden = true; });
recommendationsBackdrop.addEventListener('click', (event) => { if (event.target === recommendationsBackdrop) recommendationsBackdrop.hidden = true; });
$('#assessmentBackButton').addEventListener('click', () => { $('#assessmentForm').reset(); editingAssessment = null; closeAllModals(); });
$('#deleteAssessmentButton').addEventListener('click', () => {
  if (!editingAssessment) return;
  const confirmed = window.confirm('Are you sure you want to delete this assessment?');
  if (!confirmed) return;
  const student = editingAssessment.student;
  const index = student.assessments.indexOf(editingAssessment.assessment);
  if (index >= 0) student.assessments.splice(index, 1);
  saveClasses();
  refreshActiveClassViews();
  $('#assessmentForm').reset();
  editingAssessment = null;
  closeAllModals();
  showToast('Assessment deleted successfully.');
});
$('#openAssessmentFromStrip').addEventListener('click', openAssessmentModal);
$('#studentBackButton').addEventListener('click', () => { $('#studentForm').reset(); editingStudent = null; closeAllModals(); });
function openStudentModal(student = null) {
  editingStudent = student;
  $('#studentModalTitle').textContent = student ? 'Edit student' : 'Add student';
  $('#saveStudentButton').textContent = student ? 'Save changes' : 'Add student';
  $('#deleteStudentButton').hidden = !student;
  $('#studentForm').elements.name.value = student?.name || '';
  $('#studentForm').elements.surname.value = student?.surname || '';
  $('#studentForm').elements.middleName.value = student?.middleName || '';
  $('#studentForm').elements.gender.value = student?.gender || 'Male';
  studentModalBackdrop.hidden = false;
}
$('#openStudentFromEmpty').addEventListener('click', () => openStudentModal());
$('#openStudentFromRoster').addEventListener('click', () => openStudentModal());
$('#editSelectedStudent').addEventListener('click', () => { if (selectedStudent) openStudentModal(selectedStudent); else showToast('Choose a student to edit first.'); });
$('#deleteStudentButton').addEventListener('click', () => {
  if (!editingStudent) return;
  if (!window.confirm(`Delete ${editingStudent.displayName || editingStudent.name}? This will also remove the student's assessments.`)) return;
  activeClass.students = activeClass.students.filter((student) => student !== editingStudent);
  selectedStudent = activeClass.students[0] || null;
  saveClasses();
  editingStudent = null;
  closeAllModals();
  refreshActiveClassViews();
  showToast('Student deleted successfully.');
});
function openClassForm(classToEdit = null) {
  editingClassId = classToEdit ? classToEdit.id : null;
  pendingSubjects = classToEdit ? [...classToEdit.subjects] : [];
  $('#classModalTitle').textContent = classToEdit ? 'Edit class' : 'Create class';
  $('#saveClassButton').textContent = classToEdit ? 'Save changes' : 'Save class';
  $('#classForm').elements.course.value = classToEdit?.course || '';
  $('#classForm').elements.year.value = classToEdit?.year || '3rd Year';
  $('#classForm').elements.section.value = classToEdit?.section || '';
  $('#subjectChips').innerHTML = pendingSubjects.map((subject) => `<span class="subject-chip">${subject}<button type="button" data-subject="${subject}">×</button></span>`).join('');
  classModalBackdrop.hidden = false;
}
$('#openClassMakerFromManager').addEventListener('click', () => openClassForm());
document.querySelectorAll('.close-button').forEach((button) => button.addEventListener('click', closeAllModals));
document.querySelectorAll('.modal-backdrop').forEach((backdrop) => backdrop.addEventListener('click', (event) => { if (event.target === backdrop) closeAllModals(); }));
subjectFilter.addEventListener('change', filterAssessments);
searchInput.addEventListener('input', filterAssessments);
document.querySelector('.filter-button')?.addEventListener('click', () => { filterAssessments(); showToast('Assessment list filtered.'); });
document.querySelector('.view-all')?.addEventListener('click', () => {
  subjectFilter.value = 'all';
  searchInput.value = '';
  filterAssessments();
  assessmentRows.scrollIntoView({ behavior: 'smooth', block: 'start' });
  showToast('Showing all assessments.');
});

$('#addSubject').addEventListener('click', () => { const input = $('#subjectInput'); const subject = input.value.trim(); if (!subject || pendingSubjects.includes(subject)) return; pendingSubjects.push(subject); $('#subjectChips').innerHTML = pendingSubjects.map((item) => `<span class="subject-chip">${item}<button type="button" data-subject="${item}">×</button></span>`).join(''); input.value = ''; });
$('#subjectChips').addEventListener('click', (event) => { if (event.target.matches('button')) { pendingSubjects = pendingSubjects.filter((item) => item !== event.target.dataset.subject); event.target.parentElement.remove(); } });
$('#rosterSort')?.addEventListener('change', () => renderStudentCards());
$('#studentCards').addEventListener('click', (event) => { const card = event.target.closest('.student-card'); if (!card) return; selectedStudent = activeClass.students.find((student) => student.name === card.dataset.student); renderStudentSelect(); renderSubjectPerformance(); showToast(`${selectedStudent.name}'s profile loaded.`); });
assessmentRows.addEventListener('click', (event) => { const button = event.target.closest('.edit-assessment'); if (!button) return; openEditAssessment(button.dataset.student, Number(button.dataset.assessmentIndex)); });

$('#classCards').addEventListener('click', (event) => { const action = event.target.dataset.action; const id = event.target.dataset.id; if (!action) return; const item = classes.find((entry) => entry.id === id); if (action === 'edit') openClassForm(item); if (action === 'delete' && confirm(`Delete ${classLabel(item)}?`)) { classes = classes.filter((entry) => entry.id !== id); activeClass = classes[0] || { id: 'empty', course: 'No class', year: '', section: '', subjects: [], students: [] }; selectedStudent = activeClass.students[0] || null; saveClasses(); refreshActiveClassViews(); showToast('Class deleted.'); } });

$('#classForm').addEventListener('submit', (event) => { event.preventDefault(); if (!pendingSubjects.length) return showToast('Add at least one subject first.'); const form = new FormData(event.target); const course = formatCourse(form.get('course')); const year = form.get('year'); const section = form.get('section').trim().toUpperCase(); const subjects = pendingSubjects.map((subject) => titleCase(subject)); if (editingClassId) { const item = classes.find((entry) => entry.id === editingClassId); item.course = course; item.year = year; item.section = section; item.subjects = subjects; activeClass = item; showToast('Class updated successfully.'); } else { const newClass = { id: `class-${Date.now()}`, course, year, section, subjects, students: [] }; classes.push(newClass); activeClass = newClass; selectedStudent = null; showToast('Class created successfully.'); } saveClasses(); refreshActiveClassViews(); event.target.reset(); closeAllModals(); });

$('#studentForm').addEventListener('submit', (event) => { event.preventDefault(); const form = new FormData(event.target); const name = formatStudentName(form.get('name')); const surname = formatSurname(form.get('surname')); const middleName = form.get('middleName') ? formatStudentName(form.get('middleName')) : ''; const gender = form.get('gender') || 'Male'; const displayName = `${surname}, ${name}`; if (editingStudent) { editingStudent.name = name; editingStudent.surname = surname; editingStudent.middleName = middleName; editingStudent.gender = gender; editingStudent.displayName = displayName; editingStudent.initials = initials(surname || name); selectedStudent = editingStudent; showToast('Student updated successfully.'); } else { const student = { name, surname, middleName, gender, displayName, initials: initials(surname || name), assessments: [] }; activeClass.students.push(student); selectedStudent = student; showToast('Student added successfully.'); } saveClasses(); refreshActiveClassViews(); if (editingStudent) { event.target.reset(); editingStudent = null; closeAllModals(); return; }
  event.target.reset(); $('#studentForm').elements.gender.value = 'Male'; $('#studentForm').elements.name.focus(); });

$('#assessmentForm').addEventListener('submit', (event) => { event.preventDefault(); if (!validateAssessmentScore()) { showToast('Score cannot be greater than Out of.'); return; } const form = new FormData(event.target); const studentName = form.get('student') || $('#assessmentStudent')?.value; const targetStudent = editingAssessment?.student || activeClass.students.find((student) => student.name === studentName); if (!targetStudent) return showToast('Choose a student before recording an assessment.'); const total = Number(form.get('total')); const score = Number(form.get('score')); const dateValue = form.get('date'); const timeValue = form.get('time') || localTimeValue(); const date = new Date(`${dateValue}T${timeValue}`); const updatedAssessment = { title: formatAssessmentTitle(form.get('title')), subject: titleCase(form.get('subject')), type: titleCase(form.get('type')), period: form.get('period'), score, total, date: dateValue, time: timeValue, dateTime: `${dateValue}T${timeValue}`, dateLabel: date.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' }) }; const duplicateExam = !editingAssessment && targetStudent.assessments.some((assessment) => isSameExamPeriod(assessment, updatedAssessment)); if (duplicateExam) { showToast('This student already has an exam for this subject and academic period. Delete the existing exam before adding another.'); return; } if (editingAssessment) { Object.assign(editingAssessment.assessment, updatedAssessment); selectedStudent = editingAssessment.student; showToast('Assessment updated successfully.'); } else { targetStudent.assessments.push(updatedAssessment); selectedStudent = targetStudent; showToast('Assessment added successfully.'); } saveClasses(); refreshActiveClassViews(); if (editingAssessment) { event.target.reset(); editingAssessment = null; closeAllModals(); return; }
  $('#assessmentScore').value = ''; validateAssessmentScore(); showToast('Assessment added. Enter the next score when ready.'); });

renderClassOptions();
renderCurrentDate();
$('#activeClassBannerName').textContent = classLabel(activeClass);
renderSubjects();
renderStudentSelect();
renderReports();
$('#classManagerView').hidden = true;
arrangeOverviewSections();
